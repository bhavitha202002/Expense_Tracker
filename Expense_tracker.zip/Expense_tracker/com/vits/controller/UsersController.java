package com.vits.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.vits.entity.Users;
import com.vits.service.UsersService;

@RestController
@RequestMapping("/api/users")
public class UsersController 
{
	@Autowired
	private UsersService userService;
	
	@PostMapping("/register")
    public ResponseEntity<Users> registerUser(@RequestBody Users user) {
        Users newUser = userService.register(user);
        return new ResponseEntity<>(newUser, HttpStatus.CREATED);
    }
}
