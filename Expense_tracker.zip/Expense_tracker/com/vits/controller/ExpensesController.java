package com.vits.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.vits.entity.Category;
import com.vits.entity.Expenses;
import com.vits.entity.Users;
import com.vits.service.ExpensesService;

@RestController
@RequestMapping("/api/expenses")
public class ExpensesController {
	@Autowired
	private ExpensesService expenseService;
	
	@PostMapping("/add")
    public ResponseEntity<Expenses> addExpense(@RequestBody Expenses expense) {
        Expenses createdExpense = expenseService.createExpense(expense);
        return new ResponseEntity<>(createdExpense, HttpStatus.CREATED);
    }
	
	// Get expenses by ID
    @GetMapping("/{userId}")
    public ResponseEntity<List<Expenses>> getAllExpensesByUser(@PathVariable Long userId) {
     Users user = new Users();
     user.setId(userId);
     List<Expenses> expenses = expenseService.getExpensesByUser(user);
     return new ResponseEntity<>(expenses, HttpStatus.OK);
    }
    
    // Get expenses by category
    @GetMapping("/category/{id}")
    public ResponseEntity<List<Expenses>> getAllExpensesByCategory(@PathVariable Long id)
    {
    	Category category = new Category();
    	category.setId(id);
    	List<Expenses> expenses = expenseService.getExpensesByCategory(category);
    	return new ResponseEntity<>(expenses,HttpStatus.OK);
    }
    
 // Update an expense by ID
    @PutMapping("/{id}")
    public ResponseEntity<Expenses> updateExpenseById(@PathVariable Long id, @RequestBody Expenses updatedExpense) 
    {
    	Expenses updateExpense=expenseService.updateExpense(id,updatedExpense);
    	try { 
    	return new ResponseEntity<>(updateExpense,HttpStatus.OK);}
    	catch(Exception e)
    	{
    		return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    	}
    }

   // Delete an expense by ID
    
    @DeleteMapping("/{id}")
    public String deleteExpenseById(@PathVariable Long id) 
    {
    	String s=expenseService.deleteExpense(id);
    	return s;
    }
}
