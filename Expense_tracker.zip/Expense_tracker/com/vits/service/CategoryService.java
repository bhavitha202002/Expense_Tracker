package com.vits.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vits.entity.Category;
import com.vits.entity.Expenses;
import com.vits.entity.Users;
import com.vits.repository.CategoryRepository;

@Service
public class CategoryService {
    private CategoryRepository categoryRepository;

    @Autowired
    public CategoryService(CategoryRepository categoryRepository) {
        this.categoryRepository = categoryRepository;
    }
    

    // Implement category-related services (add, edit, delete, etc.)
    public Category add(Category category)
    {
    	return categoryRepository.save(category);
    }
}