package com.vits.service;

import java.util.List;
import java.util.Optional;

import javax.persistence.EntityNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vits.entity.Category;
import com.vits.entity.Expenses;
import com.vits.entity.Users;
import com.vits.repository.ExpensesRepository;

@Service
public class ExpensesService {
    
    @Autowired
    private ExpensesRepository expenseRepository;

    
    public Expenses createExpense(Expenses expense) {
        // You can add validation or business logic here before saving the expense
        return expenseRepository.save(expense);
    }
    
    public List<Expenses> getExpensesByUser(Users user) {
        return expenseRepository.findByUser(user);
    }
    
    public List<Expenses> getExpensesByCategory(Category category) {
        return expenseRepository.findByCategory(category);}

    // Implement other expense-related services (add, edit, delete, etc.)
    
    public Expenses updateExpense(Long id, Expenses updatedExpense) 
    {
        // Check if the expense with the given ID exists
        Optional<Expenses> existingExpense = expenseRepository.findById(id);
        if (existingExpense.isPresent()) 
        {
            updatedExpense.setId(id);
            return expenseRepository.save(updatedExpense);
        } 
        else 
        {
            throw new EntityNotFoundException("Expense not found with ID: " + id);
        }
    }

    public String deleteExpense(Long id) 
    {
        // Check if the expense with the given ID exists before deleting
        if (expenseRepository.existsById(id)) 
        {
            expenseRepository.deleteById(id);
            return "Expense with id " +id+"is delted Successfully";
        } else 
        {
            return "Expense not found with ID: " + id;
        }
    }
}