package com.vits.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.vits.entity.Users;

@Repository
public interface UsersRepository extends CrudRepository<Users,Long>
{
	Users findByUsername(String username);
}
