package com.vits.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.vits.entity.Category;
import com.vits.entity.Expenses;
import com.vits.entity.Users;

@Repository
public interface CategoryRepository extends CrudRepository<Category,Long>{


}
