package com.vits;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExpenseTrackerThreeEntitiesApplicationTests {

	@Test
	void contextLoads() {
	}

}
